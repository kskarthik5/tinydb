from tinydb import TinyDB, where
from tinydb.storages import JSONStorage
from tinydb.middlewares import SimulateError
db = TinyDB('testdb.json',storage=JSONStorage)
tbl = db.table('our_table')
